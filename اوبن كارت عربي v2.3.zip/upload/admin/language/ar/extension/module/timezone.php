<?php
// Heading
$_['heading_title'] = 'تعديل توقيت السيرفر';

$_['text_module'] = 'الموديولات';
$_['text_success'] = 'تم التعديل بنجاح !';
$_['text_edit'] = 'تحرير';

// Entry
$_['entry_status'] = 'الحالة';
$_['entry_timezone'] = 'التوقيت';
$_['entry_php_time'] = 'توقيت بي اتش بي - PHP Time:';
$_['entry_db_time'] = 'توقيت قاعدة البيانات:';

// Error
$_['error_permission'] = 'تحذير: انت لا تمتلك صلاحيات التعديل !';
