<?php
// Heading
$_['heading_title'] = 'Timezone Sync';

$_['text_module'] = 'Modules';
$_['text_success'] = 'Success: You have modified this module!';
$_['text_edit'] = 'Edit ' . $_['heading_title'] . ' Module';

// Entry
$_['entry_status'] = 'Status';
$_['entry_timezone'] = 'Timezone';
$_['entry_php_time'] = 'PHP Time:';
$_['entry_db_time'] = 'Database Time:';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify this module!';