<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']    = 'محرر القوالب';

// Text
$_['text_success']     = 'تم التعديل !';
$_['text_edit']        = 'تحرير';
$_['text_store']       = 'اختيار المتجر';
$_['text_template']    = 'اختيار القالب';
$_['text_default']     = 'الافتراضي';
$_['text_warning']     = 'تحذير: Security can be compromised using the theme editor!';
$_['text_access']      = 'تأكد من ان يتم السماح فقط للمدراء المخولين الدخول الى هذه الصفحة.';
$_['text_permission']  = 'يمكنك تعديل صلاحيات المدراء <a href="%s" class="alert-link">من هنا</a>.';
$_['text_begin']       = 'قم باختيار ملف القالب المطلوب لبدء التحرير.';

// Error
$_['error_permission'] = 'تحذير: انت لا تمتلك صلاحيات التعديل !';
