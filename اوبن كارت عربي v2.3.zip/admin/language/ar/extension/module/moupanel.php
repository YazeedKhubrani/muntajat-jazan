<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

$_['heading_title']       				= 'تخصيص الوان القالب';
$_['edit_title']       				= 'تحرير تخصيص الوان القالب';
$_['text_success']       				= 'تم التعديل';
$_['button_stay']       			= 'حفظ وتحرير';

// Text
$_['text_extension']         = 'الاضافات';

//General
$_['text_dropdownhover']                      = 'لون مرور الماوس للقائمة المنسدلة ';
$_['text_dropdownbg']                      = 'لون خلفية مرور الماوس';
$_['text_titlecolor']                      = 'لون العناويين';
$_['text_titlecolor']                      = 'لون العناويين';
$_['text_linkcolor']                      = 'لون الروابط';
$_['text_linkhover']                      = 'لون مرور ماوس الروابط';
$_['text_color']                      = 'اللون:';
$_['text_hover']                      = 'لون مرور الماوس:';
$_['text_background']                      = 'الخلفية';
$_['text_backgroundhover']                      = 'مرور ماوس الخلفية';
$_['tab_themepanel']                 = 'تصميم';
$_['text_general']                 = 'عام';
$_['help_general']                 = 'يمكنك تغيير صورة او لون الخلفية والوان النصوص والروابط. ولاستعادة الافتراضي يجب افراغ جميع الخانات.';
$_['entry_backgroundimage']                 = 'صورة الخلفية';
$_['entry_repeatbackground']                = 'تكرار صورة الخلفية';
$_['entry_backgroundcolor']                 = 'لون الخلفية';


$_['help_backgroundimage']				= 'صورة الخلفية';
$_['help_title']				= 'يشمل: h1, h2, h3, h4, h5, h6';
$_['help_dropdownlihover']                      = 'اغلب القوائم المنسدلة وليس الكل';
//header
//Top Nav
$_['text_topiconsize']                 = 'مقاس الايقونة:';
$_['text_topnavbg']                 = 'الخلفية';
$_['text_topborderline']                 = 'سماكة الحدود:';
$_['text_topcolorline']                 = 'لون الحدود:';
$_['text_toplanguagebghv']                 = 'خلفية مرور الماوس للقائمة المنسدلة:';
$_['text_toplanguagecolorhv']                 = 'لون مرور الماوس للقائمة المنسدلة:';
$_['text_topaccountcolorhv']                 = 'مرور الماوس للقائمة العلوية:';
$_['text_toplink']                     = 'الروابط:';
$_['text_toplinkhover']                 = 'مرور ماوس الروابط:';
$_['help_topborderline']                 = 'اضف مقياس البكسل(مثل: 2px). ضع القيمة صفر في حالة عدم الاستخدام, اترك القيمة فارغة للافتراضي';
$_['help_languagebghv']                 = 'يشمل اللغة والعملة والقائمة المنسدلة';
$_['help_accounthv']                 = 'يتم تطبيقه للقائمة المنسدلة للحساب';
//End Top Nav
//Search
$_['text_searchinput']                 = 'لون الخلفية';
$_['text_searchbutton']                 = 'لون خلفية الزر';
$_['text_searchbuttonhv']                 = 'مرور ماوس خلفية الزر';
//Cart
$_['text_cartopen']                 = 'لون النص';
$_['text_cartopenborder']                 = 'الحدود';
$_['text_cartopenbg']                 = 'الخلفية';
$_['text_cartopenborderwidth']                 = 'سماكة حدود السلة';
//Menu
$_['text_border']                 = 'الحدود';
$_['text_bordercolor']                 = 'لون الحدود';
$_['text_menulibghover']                 = 'خلفية مرور الماوس';

$_['text_menulilinkhover']                 = 'الحدود';
$_['text_bordercolor']                = 'لون الحدود';
$_['text_top_bar']                 = 'الجزء العلوي';
$_['text_top_cart']                 = 'السلة العلوية';
$_['text_top_search']                 = 'صندوق البحث';
$_['text_top_menu']                 = 'الاقسام العلوية';
$_['text_seeall']                 = 'عرض الكل';

$_['text_dropdown']                 = 'قائمة منسدلة';

$_['text_dropdownbg']                 = 'خلفية القائمة المنسدلة';
$_['text_dropdowncolor']                 = 'الوان روابط القائمة المنسدلة';

// Product list
$_['text_product_list']                 = 'قائمة المنتجات';
$_['help_product_list']                 = 'قائمة المنتجات تشمل: صفحة الاقسام وموديولات المنتجات المميزة والاكثر مبيعا وغيرها.';

$_['text_product_name']                 = 'الاسم';
$_['text_product_description']                 = 'الوصف';
$_['text_product_price']                 = 'السعر';
$_['text_add_to_cart']                 = 'زر اضافة للسلة';
$_['text_wishlist']                 = 'زر الامنيات والمقارنة';

$_['text_btgroup']                 = 'مجموعة الازرار';
$_['help_btgroup']                 = 'اضافة للسلة والامنيات والمقارنة';
$_['text_border_left']                 = 'الحد الايسر';


// Footer
$_['text_footer']                 = 'الفوتر';
$_['text_border_top']                 = 'الحد الاعلى';
// CSS
$_['tab_custom_css']				= 'مخصص CSS/Javascript/Code';
$_['entry_status']				= 'الحالة';



$_['text_custom_css'] 					= 'مخصص CSS';
$_['text_content_css'] 					= 'CSS';
$_['text_help_css'] 				= 'استخدم سي اس اس نظيف بدون تاجات';

//Javascript

$_['text_custom_javascript'] 					= 'مخصص Javascript';
$_['text_content_javascript'] 					= 'Javascript';
$_['text_help_javascript'] 				= 'استخدم جافا سكربت نظيف بدون تاجات';

//Code
$_['text_custom_code'] 					= 'كود مخصص';
$_['text_content_code'] 					= 'الكود';
$_['text_help_code'] 				= 'استخدم كود كامل';

$_['error_permission']    		= 'تحذير: انت لا تمتلك صلاحيات التعديل';
