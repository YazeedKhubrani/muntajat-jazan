<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

$_['heading_title'] = 'تأكيد البريد الالكتروني';
$_['module_title'] = 'تأكيد البريد الالكتروني';


//text

$_['text_extension'] = 'الاضافات';
$_['text_module_settings'] = 'اعدادات';
$_['text_tab_settings'] = 'اعدادات تأكيد البريد الالكتروني';
$_['text_enabled'] = 'تمكين';
$_['text_disabled'] = 'تعطيل';
$_['subject_text']				= 'الموضوع';
$_['default_subject']	 = 'الرجاء تأكيد بريدك الالكتروني';
$_['default_message'] = '<p>مرحبا ،، {firstname} {lastname},</p>
						<p>شكراً لتسجيلك معنا !</p>
						 <p>الرجاء النقر على الرابط التالي لتأكيد بريدك الالكتروني وتفعيل حسابك.</p>
						 <p>{email-link}</p>
						';
$_['user_mail']					= 'رسالة الى العميل :';
$_['user_mail_help']			= 'سيتم انشاء رسالة تلقائية تحتوي على رابط تأكيد البريد الالكتروني.
<p>استخدم الأكواد التالية :<br />
{firstname} - للاسم الأول<br />
{lastname} - للاسم الاخير<br />
{email-link} - رابط التأكيد، الذي سيتم انشاؤه تلقائياً<br />';

$_['entry_status']        		= 'الحالة :';
$_['entry_status_help']        	= 'تمكين أو تعطيل هذا الموديول';
$_['entry_customer_group_help']        	= 'اختيار مجموعة العميل لتأكيد البريد الالكتروني.';

//buttons
$_['button_save'] = 'حفظ';
$_['button_cancel'] = 'الغاء';
