<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']	  = 'OpenBay Pro';

// Text
$_['text_extension']    = 'الموديولات';
$_['text_installed'] = 'OpenBay Pro module is now installed. It is available under Extensions -> OpenBay Pro';